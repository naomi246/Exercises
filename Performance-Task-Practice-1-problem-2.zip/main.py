#peformance task practice 1 problem 2
class RangeError(Exception):
  pass

#each 
while True: 
  try: 
    N = int(input("Starting number: "))
    K = int(input("Number of shifts: "))
    if K < 0: 
      raise RangeError
 
      
    sum=N 
    
    for i in range(K):
      N *= 10
      sum += N

    print("The shifty sum is", sum)
    break
      
      
  except RangeError: 
    print("Please enter a positive integer.")
    continue

  except ValueError: 
    print("Please enter an integer.")
  